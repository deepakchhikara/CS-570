/* Assignment - 2 
 * Name- Deepak
 * CWID: 10442727 
 * 
 * */
public class Complexity {

	static int total = 0;	
	// Method 1: Complexity with O(n^2).
	public static void method1(int n) {
		int counter = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				System.out.println("Operation " + counter);
				counter++; 
				}}
		System.out.println("Time complexity O(n^2) is : " + counter);
	 }
	
	// Method 2: Complexity with O(n^3)
	 public static void method2(int n) {
		 int counter = 0;
		 for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
					for (int k = 0; k < n; k++) {
						System.out.println("Operation " + counter);
						counter++;
					}
				}
		 	}
		 System.out.println("Time complexity O(n^3) is: " + counter);
	 }
	 // Method 3: Complexity with O(log n)
	 public static void method3(int n) {
		 int counter = 0;
		 for (int i = 1; i < n; i = i * 2) {
			 System.out.println("Operation " + counter); // Counted number of operations performed
			 counter++;
		 }
		 System.out.println("Time complexity O(log n) is: " + counter);
	 }
	 //Method 4: Complexity with O(n log n):
	 public static void method4(int n) {
		 int counter = 0;
		 for (int i = 1; i <= n; i++) {
			    for(int j = 1; j < n; j = j * 2) {
			    	System.out.println("Operation " + counter);
			    	counter++;
			    }
		}
		 System.out.println("Time complexity O(nlogn) is: " + counter);
	 }
	 
	//Method 5: Complexity with O(log log n).
		 public static void method5(int n) {
			 int counter = 0;
			 for (double i = 2; i < n; i = i * i) {
				 System.out.println("Operation " + counter);
				 counter++;
			}
			 System.out.println("Time complexity O(loglogn) is: " + counter);
		 }
		 //Method 6:complexity with O(2^n).
		 public static int method6(int n) {
			
			 if(n == 0) {
				 total++;
				 System.out.println("Operation " + total);
				 return total;
			 }
			 else if(n == 1) {
				 System.out.println("Operation " + total);
				 total++;
				 System.out.println("Operation " + total);
				 total++;
				 
				 return total;
			 }
			 method6(n-1);
			 method6(n-1);
			 return total;
		 }
			
	public static void main(String[] args) {
		System.out.println("Method1 with complexity of O(n^2) being executed:");
		method1(3);
		System.out.println("Method2 with complexity of O(n^3) being executed:");
        method2(2);
        System.out.println("Method3 with complexity of O(log n) being executed:");
        method3(30);
        System.out.println("Method4 with complexity of O(n log n) being executed:");
        method4(7);
        System.out.println("Method5 with complexity of O(log log n) being executed:");
        method5(512);
        System.out.println("Method6 with complexity of O(2^n) being executed:");
        method6(9);

	}}
