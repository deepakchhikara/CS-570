/*
 * Name- Deepak
 * CWID: 10442727
 * Assignment- 4
 * 
 * */

package Assignment4;

import java.awt.Color;

public interface GridColors {
	
	Color PATH = Color.green;
    Color BACKGROUND = Color.white;
    Color NON_BACKGROUND = Color.red;
    Color ABNORMAL = NON_BACKGROUND;
    Color TEMPORARY = Color.black;

}
